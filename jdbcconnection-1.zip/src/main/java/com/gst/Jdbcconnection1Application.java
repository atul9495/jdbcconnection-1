package com.gst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jdbcconnection1Application {

	public static void main(String[] args) {
		SpringApplication.run(Jdbcconnection1Application.class, args);
	}

}
